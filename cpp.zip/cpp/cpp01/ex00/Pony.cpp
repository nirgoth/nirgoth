/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Pony.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rbeach <rbeach@student.21-school.ru>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/07 13:36:45 by rbeach            #+#    #+#             */
/*   Updated: 2021/02/12 10:39:11 by rbeach           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Pony.hpp"

Pony::Pony(std::string pony_name) : _pony_name(pony_name)
{
	std::cout << "Pony " << _pony_name << " is born" << std::endl;
}

Pony::~Pony(void)
{
	std::cout << "Pony " << _pony_name << " is died" << std::endl;
}

void Pony::sleep(void)
{
	std::cout << "Pony " << _pony_name << "is sleeping" << std::endl;
}
