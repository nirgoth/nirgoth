/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rbeach <rbeach@student.21-school.ru>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/06 18:06:15 by rbeach            #+#    #+#             */
/*   Updated: 2021/02/12 10:43:02 by rbeach           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Pony.hpp"

void ponyOnTheStack(void)
{
	Pony	horse = Pony("OnTheStack");

	horse.sleep();
}

void ponyOnTheHeap(void)
{
	Pony	*horse = new Pony("OnTheHeap");

	horse->sleep();
	delete horse;
}

int main(void)
{
	std::cout << "Next line - ponyOnTheStack();" << std::endl;
	ponyOnTheStack();
	std::cout << "PonyOnTheStack() finished" << std::endl;
	std::cout << "Next line - ponyOnTheHeap();" << std::endl;
	ponyOnTheHeap();
	std::cout << "PonyOnTheHeap() finished" << std::endl;
	return (0);
}
